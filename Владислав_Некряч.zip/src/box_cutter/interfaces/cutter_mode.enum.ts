export enum CutterMode {
  HORIZONTAL,
  VERTICAL,
}
