export enum PointCoordinate {
  X,
  Y,
}
